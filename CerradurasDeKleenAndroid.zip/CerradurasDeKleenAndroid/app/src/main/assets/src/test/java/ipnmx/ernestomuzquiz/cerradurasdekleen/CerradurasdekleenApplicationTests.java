package ipnmx.ernestomuzquiz.cerradurasdekleen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CerradurasdekleenApplicationTests {

	@Test
	void contextLoads() {
	}

}
